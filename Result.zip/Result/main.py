
from flask import Flask, render_template, request, redirect, url_for, flash
import json
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

class Student:
    def __init__(self, roll_no, name):
        self.roll_no = roll_no
        self.name = name
        self.marks = {}

    def add_marks(self, subject, mark):
        self.marks[subject] = mark

    def calculate_total(self):
        return sum(self.marks.values())

    def calculate_percentage(self):
        if len(self.marks) == 0:
            return 0
        return (self.calculate_total() / len(self.marks))

    def to_dict(self):
        return {
            'roll_no': self.roll_no,
            'name': self.name,
            'marks': self.marks
        }

    @classmethod
    def from_dict(cls, data):
        student = cls(data['roll_no'], data['name'])
        student.marks = data['marks']
        return student

class StudentResultManagementSystem:
    def __init__(self):
        self.students = {}
        self.load_data()

    def save_data(self):
        data = {roll_no: student.to_dict() for roll_no, student in self.students.items()}
        with open('students_data.json', 'w') as f:
            json.dump(data, f)

    def load_data(self):
        if os.path.exists('students_data.json'):
            try:
                with open('students_data.json', 'r') as f:
                    data = json.load(f)
                self.students = {roll_no: Student.from_dict(student_data) 
                               for roll_no, student_data in data.items()}
            except:
                self.students = {}

    def add_student(self, roll_no, name):
        self.students[roll_no] = Student(roll_no, name)
        self.save_data()

    def add_marks(self, roll_no, subject, mark):
        if roll_no in self.students:
            self.students[roll_no].add_marks(subject, mark)
            self.save_data()
            return True
        return False

    def get_student(self, roll_no):
        return self.students.get(roll_no)

    def search_by_name(self, name):
        for roll_no, student in self.students.items():
            if student.name.lower() == name.lower():
                return student
        return None

    def get_all_students(self):
        return list(self.students.values())

# Initialize the system
system = StudentResultManagementSystem()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        roll_no = request.form['roll_no']
        name = request.form['name']
        
        if roll_no in system.students:
            flash('Student with this roll number already exists!', 'error')
        else:
            system.add_student(roll_no, name)
            flash('Student added successfully!', 'success')
            return redirect(url_for('index'))
    
    return render_template('add_student.html')

@app.route('/add_marks', methods=['GET', 'POST'])
def add_marks():
    if request.method == 'POST':
        roll_no = request.form['roll_no']
        subject = request.form['subject']
        mark = float(request.form['mark'])
        
        if system.add_marks(roll_no, subject, mark):
            flash('Marks added successfully!', 'success')
        else:
            flash('Student not found!', 'error')
        
        return redirect(url_for('index'))
    
    return render_template('add_marks.html', students=system.get_all_students())

@app.route('/view_result/<roll_no>')
def view_result(roll_no):
    student = system.get_student(roll_no)
    if student:
        return render_template('view_result.html', student=student)
    else:
        flash('Student not found!', 'error')
        return redirect(url_for('index'))

@app.route('/search_result', methods=['GET', 'POST'])
def search_result():
    if request.method == 'POST':
        name = request.form['name']
        student = system.search_by_name(name)
        if student:
            return render_template('view_result.html', student=student)
        else:
            flash('Student not found!', 'error')
    
    return render_template('search_result.html')

@app.route('/all_students')
def all_students():
    students = system.get_all_students()
    return render_template('all_students.html', students=students)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
